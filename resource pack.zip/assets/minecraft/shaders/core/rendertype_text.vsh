#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_075e5d7b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_294d5f51() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_10512cf8(inout vec4 vertex) {
    f_075e5d7b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_294d5f51();
    }
    finalize();
}



void f_ef52dc48() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_63f99472() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c84ab423(inout vec4 vertex) {
    f_075e5d7b(vertex);
    f_ef52dc48();
    finalize();
}

void f_265cd7c5(inout vec4 vertex) {
    f_075e5d7b(vertex);
    f_294d5f51();
    f_63f99472();
    finalize();
}

void f_7f492689(inout vec4 vertex) {
    f_075e5d7b(vertex);
    f_63f99472();
    f_ef52dc48();
    finalize();
}

void f_55e3cd92(inout vec4 vertex) {
    f_294d5f51();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_075e5d7b(vertex);
    finalize();
}

void f_4ae9a02a(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_ef52dc48();
    f_075e5d7b(vertex);
    finalize();
}

void f_6778f16e(inout vec4 vertex, float speed) {
    f_075e5d7b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_c167b121(inout vec4 vertex) {
    f_075e5d7b(vertex);
    f_294d5f51();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_10512cf8(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_294d5f51();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_075e5d7b(vertex);
            f_294d5f51();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_265cd7c5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_265cd7c5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_55e3cd92(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_55e3cd92(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_6778f16e(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_c167b121(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c84ab423(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_265cd7c5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_7f492689(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_55e3cd92(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_4ae9a02a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_6778f16e(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c84ab423(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_265cd7c5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_7f492689(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_55e3cd92(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_4ae9a02a(vertex);
        return;
    }
    

    
    f_075e5d7b(vertex);
    f_294d5f51();
    finalize();
}