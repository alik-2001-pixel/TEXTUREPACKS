#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_8ae9fb7c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_6297e4f3() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_94ec7e41(inout vec4 vertex) {
    f_8ae9fb7c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_6297e4f3();
    }
    finalize();
}



void f_b2a677cb() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_9b7aeaad() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_589e7fa5(inout vec4 vertex) {
    f_8ae9fb7c(vertex);
    f_b2a677cb();
    finalize();
}

void f_f5d857b0(inout vec4 vertex) {
    f_8ae9fb7c(vertex);
    f_6297e4f3();
    f_9b7aeaad();
    finalize();
}

void f_ed4fddd2(inout vec4 vertex) {
    f_8ae9fb7c(vertex);
    f_9b7aeaad();
    f_b2a677cb();
    finalize();
}

void f_023f1621(inout vec4 vertex) {
    f_6297e4f3();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_8ae9fb7c(vertex);
    finalize();
}

void f_70c6aa59(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b2a677cb();
    f_8ae9fb7c(vertex);
    finalize();
}

void f_5e9ce6c3(inout vec4 vertex, float speed) {
    f_8ae9fb7c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_ab702f5f(inout vec4 vertex) {
    f_8ae9fb7c(vertex);
    f_6297e4f3();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_94ec7e41(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_6297e4f3();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_8ae9fb7c(vertex);
            f_6297e4f3();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_f5d857b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_f5d857b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_023f1621(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_023f1621(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_5e9ce6c3(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_ab702f5f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_589e7fa5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_f5d857b0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_ed4fddd2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_023f1621(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_70c6aa59(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_5e9ce6c3(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_589e7fa5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_f5d857b0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_ed4fddd2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_023f1621(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_70c6aa59(vertex);
        return;
    }
    

    
    f_8ae9fb7c(vertex);
    f_6297e4f3();
    finalize();
}