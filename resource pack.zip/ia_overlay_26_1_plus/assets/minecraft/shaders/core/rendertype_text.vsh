#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_ae74c3ce(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ba62dbf9() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_2e2520b4(inout vec4 vertex) {
    f_ae74c3ce(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ba62dbf9();
    }
        finalize();
}



void f_a93a8c79() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_dc10bdbd() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_be90ece6(inout vec4 vertex) {
    f_ae74c3ce(vertex);
    f_a93a8c79();
    finalize();
}

void f_bf5f699f(inout vec4 vertex) {
    f_ae74c3ce(vertex);
    f_ba62dbf9();
    f_dc10bdbd();
    finalize();
}

void f_d05940ee(inout vec4 vertex) {
    f_ae74c3ce(vertex);
    f_dc10bdbd();
    f_a93a8c79();
    finalize();
}

void f_03f62697(inout vec4 vertex) {
    f_ba62dbf9();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_ae74c3ce(vertex);
    finalize();
}

void f_5674a8c8(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a93a8c79();
    f_ae74c3ce(vertex);
    finalize();
}

void f_fa8a33e4(inout vec4 vertex, float speed) {
    f_ae74c3ce(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_e7fd4961(inout vec4 vertex) {
    f_ae74c3ce(vertex);
    f_ba62dbf9();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_2e2520b4(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ba62dbf9();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_ae74c3ce(vertex);
            f_ba62dbf9();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_bf5f699f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_bf5f699f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_03f62697(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_03f62697(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_fa8a33e4(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e7fd4961(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_be90ece6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_bf5f699f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_d05940ee(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_03f62697(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5674a8c8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_fa8a33e4(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_be90ece6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_bf5f699f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_d05940ee(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_03f62697(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5674a8c8(vertex);
        return;
    }
    

    
    f_ae74c3ce(vertex);
    f_ba62dbf9();
    finalize();
}